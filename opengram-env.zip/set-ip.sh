#!/usr/bin/env bash
# Использование: ./set-ip.sh 203.0.113.10   (внешний IP или домен сервера)
set -e
[ -z "$1" ] && { echo "Укажи IP: ./set-ip.sh <IP>"; exit 1; }
sed -i -E \
 -e "s|^(App__WebRtcConnections__0__Ip)=.*|\1=$1|" \
 -e "s|^(TURN_EXTERNAL_IP)=.*|\1=$1|" \
 -e "s|^(App__DcOptions__[0-9]+__IpAddress)=.*|\1=$1|" .env
echo "Готово. IP -> $1"
